import java.util.ArrayList;

public class FixedPriceStorage extends Storage {

    public FixedPriceStorage(String storageId, double price) {
        super(storageId, price);
    }
    
}

